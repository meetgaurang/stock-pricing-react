export function Summary() {
    return (
        <div> Summary Component </div>
    );
}